class add{
    public static int marks;
    
    public static void main(String[] args){
        add();
        add();
        add();
        sub();
        System.out.println("The total marks is:" + marks);
    }
    
    public static void add(){
        marks += 1;
        System.out.println("Marks:" + marks);
    }
    
    public static void sub(){
        marks -= 1;
        System.out.println("Marks:" + marks);
    }
}