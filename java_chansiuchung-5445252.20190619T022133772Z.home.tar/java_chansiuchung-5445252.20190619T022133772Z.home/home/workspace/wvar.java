import java.util.Scanner;

class wvar{
    public static void main(String args[]) {
        int a, b, c;
        //taking value as command  line argument.
        Scanner datain = new Scanner(System.in);
        a = datain.nextInt();
        b = datain.nextInt();
        c = datain.nextInt();
        System.out.println(a+b+c);
    }
}