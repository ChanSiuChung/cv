import java.util.Scanner;





class game {





    // 2D array to represent the current state of the game 


    // If the element stores 0, it means that it is not selected by any player 


    // If the element stores 1, it means that player1 selected the element 


    // If the element stores 2, it means that player2 selected the element 





    private static int[][] board = new int[3][3];





    private static char s_player1 = 'X';


    private static char s_player2 = 'O';





    private static int currentPlayer;





    // Game Status 


    // 0 - Game ended, draw 


    // 1 - Game ended, Player 1 wins 


    // 2 - Game ended, Player 2 wins 


    // 3 - Game should continue 


    public static void main(String[] args) {


        int gameStatus;


        initBoard();





        // Set player 1 to be the first player 


        currentPlayer = 1;


        do {





            // We can check whether the game is ended before continue to player1 or player 2 


            // This is OK since if this is a completely new game, checkGameEnd will only returns 3 





            gameStatus = checkGameEnd();



            // First Print the board 


            printBoard();




            // Should we move on to player1 / player2 or end the game? 


            if (gameStatus == 0) {


            // Game ended, show the message  
                System.out.println("Draw");





            } else if (gameStatus == 1) {


                System.out.println("Player 1 wins");





            } else if (gameStatus == 2) {


                // Game ended, show the message  
                System.out.println("Player 2 wins");





                } else if (gameStatus == 3) {


                // Game should continue 





                // Then ask the player to update the board 


                if (currentPlayer == 1) {


                    player1();


                } else {


                    player2();


                }





                // Set the next player, otherwise, player1 will continue 


                // Player 1 then Player 2 then Player 1 


                if (currentPlayer == 1) {


                    currentPlayer = 2;


                } else {


                    currentPlayer = 1;


                }


            }





            } while (gameStatus == 3);


            // Only continue if the game is not ended. 


        }





    // Method to initialize the game board to the starting state 


    private static void initBoard() {


        int i, j;


        for (i = 0; i < 3; i++) {


            for (j = 0; j < 3; j++) {


                board[i][j] = 0;


            }  


        }


    }





    // Show the board to the user 


    private static void printBoard() {
    
        int i, j;
    
        for(i = 0;i < 3; i++){
            for(j = 0; j < 3;j++){
                if(j != 2){
                    if(board[i][j] == 0){
                        System.out.print("." + " ");
                    }else if(board[i][j] == 1){
                        System.out.print(s_player1 + " ");
                    }else if(board[i][j] == 2){
                        System.out.print(s_player2 + " ");
                    }
                }else{
                    if(board[i][j] == 0){
                        System.out.println("." + " ");
                    }else if(board[i][j] == 1){
                        System.out.println(s_player1+ " ");
                    }else if(board[i][j] == 2){
                        System.out.println(s_player2 + " ");
                    }
                }
            }
        }
    }





    // Player 1 turn 


    private static void player1() {

        Scanner sc = new Scanner(System.in);


        System.out.println("Player 1");


        System.out.println("Enter the row and column: ");


        // Update the baord 

        int row = sc.nextInt();


        int col = sc.nextInt();
    
        board[row][col] = 1;




    }





    // Player 2 turn  


    private static void player2() {


        Scanner sc = new Scanner(System.in);


        System.out.println("Player 2");


        System.out.println("Enter the row and column: ");

        
        // Update the baord  
        
        
        int row = sc.nextInt();


        int col = sc.nextInt();
    
        board[row][col] = 2;




    }





    // Method to check if the game should end at the current state 


    // Return an integer to represent the status 


    // 0 - Game ended, draw 


    // 1 - Game ended, Player 1 wins 


    // 2 - Game ended, Player 2 wins 


    // 3 - Game should continue 


    private static int checkGameEnd() {
        int i, j, Draw_Count;
        Draw_Count = 0;
    
        //check hori an vert
        for(i = 0; i <= 2; i++){
            if((board[0][i] == board[1][i]) && (board[1][i] == board[2][i])){
                if(board[1][i] == 1){
                    return 1;
                }else if(board[1][i] == 2){
                    return 2;
                }
            }
        }
        //check diag
        if(((board[0][0] == board[1][1]) && (board[1][1] == board[2][2])) || ((board[0][2] == board[1][1]) && (board[1][1] == board[2][0]))){
            if(board[1][1] == 1){
                return 1;
            }else if(board[1][1] == 2){
                return 2;
            }
        }
    
        for(i = 0; i < 3; i++){
            for(j = 0; j < 3; j++){
                if(board[i][j] != 0){
                    Draw_Count += 1;
                }
            }
        }
        if(Draw_Count == 9){
            return 0;
        }

        return 3;

    }


}