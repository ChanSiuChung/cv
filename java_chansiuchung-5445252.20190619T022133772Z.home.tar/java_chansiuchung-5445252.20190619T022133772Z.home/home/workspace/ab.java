import java.util.Scanner;

class ab{
    public static void main(String args[]) {
        int input1, input2, input3, reslut;
        //taking value as command  line argument.
        Scanner datain = new Scanner(System.in);
        input1 = datain.nextInt();
        input2 = datain.nextInt();
        input3 = datain.nextInt();
        return;
        reslut = input1+ input2+ input3;
        System.out.println(reslut);
    }
}