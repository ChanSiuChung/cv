import java.io.BufferedReader; 

import java.io.FileReader; 

import java.io.BufferedWriter; 

import java.io.FileWriter; 

import java.io.IOException; 

 

class task1b{ 

 

    public static void main(String[] args) throws IOException { 
    
     
    
        String fPath = "/home/ubuntu/workspace/task1b.txt"; 
        
        // read the content from file 
        
        BufferedReader br = new BufferedReader(new FileReader(fPath)); 
        
         
        
        String line = br.readLine(); 
        int i = 0;

        String L1;
        while(line != null) { 
            

            for(i = 0;i < line.length();i++){
                if(line.charAt(i)!='a'&&line.charAt(i)!='e'&&line.charAt(i)!='i'&&line.charAt(i)!='o'&&line.charAt(i)!='u'&&line.charAt(i)!='A'&&line.charAt(i)!='E'&&line.charAt(i)!='I'&&line.charAt(i)!='O'&&line.charAt(i)!='U'){
                    System.out.print(line.charAt(i));
                }
                
            }
            System.out.println();

                        
            line = br.readLine(); 
                        
            
        } 
        
    } 

}