public class sample {
    public static void main( String[] args ) {

        if (args.length > 0) {
            String inputName;
            int inputNumber = 0;
            inputName = args[0];
            try {
                inputNumber = Integer.parseInt(args[1]);
                System.out.println( inputName + " is " + inputNumber + " years old.");
            } catch (NumberFormatException e) {
                System.out.println("The second input is NOT a number!");
            }
        }
        else
        {
            System.out.println("You need to input a name and a number!");
            System.out.println("sample <name> <number>");
            System.out.println("e.g. sample Jacky 123");
        }
        System.exit( 0 ); //success
    }
}