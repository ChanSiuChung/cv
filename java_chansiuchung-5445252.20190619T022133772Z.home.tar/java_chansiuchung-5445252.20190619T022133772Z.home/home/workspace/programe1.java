import java.util.Scanner;

class programe1 { 

    public static int A[]={2,4,51,34,67,23,45,6}; 

 

    public static void main(String[] args) { 
        int start, end, p; 
        if (getchoice() == 1) { 
            start = getstart(); 
            end = getend(); 
            p = add(start, end); 
        }else{ 
            start = getstart(); 
            end = getend(); 
            p = addsq(start, end); 
        }
        System.out.println(p);
    } 

    public static int add(int start, int end) {
        int p = 0;
        for(int i = 0; i < (end - start + 1) ;i++){
            p = p + A[start + i];
        }
        return p;

    } 

 

    public static int addsq(int start, int end) { 
        int p = 0;
        for(int i = 0; i < (end - start + 1) ;i++){
            p = p + A[start + i] * A[start + i];
        }
        return p;
 

 

    } 

 

    public static int getchoice() { 

        Scanner sc = new Scanner(System.in); 

        System.out.println("Enter your choice (1 = simple add, 2 = add square): "); 

        int choice = sc.nextInt(); 

        return choice; 

    } 

 

    public static int getstart() { 

        Scanner sc = new Scanner(System.in); 

        System.out.println("Enter the starting index: "); 

        int ans = sc.nextInt(); 

        return ans; 

    } 

 

    public static int getend() { 

        Scanner sc = new Scanner(System.in); 

        System.out.println("Enter the ending index: "); 

        int ans = sc.nextInt(); 

        return ans; 

    } 

 

 

} 