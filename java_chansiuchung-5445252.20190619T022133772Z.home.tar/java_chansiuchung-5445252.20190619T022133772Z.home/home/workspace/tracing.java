class tracing {
    public static char getCheckDigit(String prefix , String digits) {
    }
}