import java.util.Scanner;
    class d303{
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            String input= di.nextLine();
            String reverse = new StringBuffer(input).reverse().toString();
            if (input.compareTo(reverse) == 0){
                System.out.println(reverse);
                System.out.println("Yes");
            }else{
                System.out.println(reverse);
                System.out.println("No");
            }
        }
    }