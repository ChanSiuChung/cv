import java.util.Scanner;
import java.util.Random;

    class pg{
        //int strings
        public static int alength;
        public static String Cap = "QWERTYUPASDFGHJKZXCVBNM";
        public static String Small = "qwertyupasdfghjkzxcvbnm";
        public static String Punc = "!@#$%^&*()_+=-[]{};':<>,./|\\";
        public static String Numb = "123456789";
        public static String other = "iI1LloO0";
        
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            int pLength, i, cap_c ,small_c, punc_c, numb_c, other_c;
            int singlechar;
            char k;
            String alto;
            
            alto = "";
            
            
            //ask length of password
            System.out.println("How long do you need for the password?Please enter a length in number");
            pLength = di.nextInt();
            
            System.out.println("Which kind of character do you want to include?");
            System.out.println("1. Capital letters");
            System.out.println("2. Small letters");
            System.out.println("3. Punctuations");
            System.out.println("4. Numbers");
            System.out.println("5.Include simular characters (eg.i, l)?");
            
            cap_c = di.nextInt();
            small_c = di.nextInt();
            punc_c = di.nextInt();
            numb_c = di.nextInt();
            other_c = di.nextInt();
            
            //read what user need
            if(cap_c == 1|| small_c == 1|| punc_c == 1){
                alto += Cap;
            }
            
            if(cap_c ==2 || small_c == 2|| punc_c == 2){
                alto += Small;
            }
            
            if(cap_c ==3|| small_c == 3|| punc_c == 3){
                alto += Punc;
            }
            if(cap_c ==4|| small_c == 4|| punc_c == 4){
                alto += Numb;
            }
            if(cap_c ==5|| small_c == 5|| punc_c == 5){
                alto += Numb;
            }
            alength = alto.length() - 1;
            
            
            //choose random numb adn print
            for(i = 0; i < pLength; i++){
                singlechar = RNG();
                k = alto.charAt(singlechar);
                System.out.print(k);
            }
        }
        
        public static int RNG(){
            //generator
            int j;
            Random rand = new Random();
            j = rand.nextInt(alength);
            return j;
        }
    
    }