import java.io.BufferedReader; 

import java.io.FileReader; 

import java.io.BufferedWriter; 

import java.io.FileWriter; 

import java.io.IOException; 

 

class FileRead { 

 

    public static void main(String[] args) throws IOException { 
    
     
    
        String fPath = "C://TEMP/DATA.TXT"; 
        
        // read the content from file 
        
        BufferedReader br = new BufferedReader(new FileReader(fPath)); 
        
         
        
        String line = br.readLine(); 
        
        while(line != null) { 
        
            System.out.println(line); 
            
            line = br.readLine(); 
        
        } 
        
    } 

}