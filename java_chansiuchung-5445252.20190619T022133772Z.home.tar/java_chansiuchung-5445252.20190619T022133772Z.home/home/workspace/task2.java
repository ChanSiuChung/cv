import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

class task2 {

    public static String[][] data = new String[200][7];
    public static String[] cache = new String[200];
    public static int NoOfStu = 0;
    public static int member = 0;
    public static int NumInGroup = 0;

    public static void main(String[] args) throws IOException {
        //init array
        for(int i = 0; i < 200;i++){
            for(int j = 0;j < 7;j++){
                data[i][j] = "";
            }
        }
        
        String filename;
        filename = getInputFileName();
        NumInGroup = getNumberOfStudentsInGroup();
        NoOfStu = ReadFileInfoCache(filename);
        ParseCache();
        AssignGroup(NumInGroup);
        PrintGroupInfo();
        System.out.println("There are " + (NoOfStu%NumInGroup) + " Groups with 1 more student." );
        
    }

    //Read the file contents into cache[]
    //Return the numbner of records found in the file
    //No Input from the keyboard and Output to the screen
    //Parameter: filename
    public static int ReadFileInfoCache(String filename) throws IOException {
        // read the content from file
        BufferedReader br = new BufferedReader(new FileReader(filename));
        int i = 0;
        //cache[0] is header.
        //cache[1] to data[0]
	    //cache[2] to data[1]
        String line = br.readLine();
        while(line != null) {
            cache[i] = line;
            line = br.readLine();
            i++;
        }
        return i - 1;
    }

    //Perform data parse on the cache
    //Put the correct contents into data[][]
    //Parameter : None
    //Return: None
    //Input and Output: None
    public static void ParseCache() {
        int k = 0;
        int comma_counter = 0;
        for(int x = 0;x < NoOfStu + 1;x++){
            k = 0;
            comma_counter = 0;
            for(int y = 0; y< 6;y++){
                String para = cache[x];
                while(k < para.length()){
                    if(para.charAt(k) != ',' && comma_counter < 6){
                        data[x][y] = data[x][y] + para.charAt(k);
                        //System.out.println(data[x][y] + " " + x + " " + y);
                        k++;
                    }else{
                        y++;
                        comma_counter++;
                        k++;
                    }
                }
            }
        }
    }


    //Assign students to group by putting values into the data[X][6] column
    //Parameter : Number of students in a group
    //Return: None
    //Input and Output: None
    public static void AssignGroup(int numgroup) {
        for(int p = 1; p<=NoOfStu + 1 ;p++){
            if(NumInGroup != 1){
                int a = (p %(NoOfStu/NumInGroup)) + 1;
                data[p][6] = "" + a;
            }else{
                int a = p;
                data[p][6] = "" + a;
            }
        }
    }

    //Output the group data to the screen
    //Parameter : None
    //Return: None
    //Input and Output: Group data to the screen
    public static void PrintGroupInfo() {
        int i;
        for (i =1; i <= NoOfStu; i++) {
            System.out.println(data[i][2] + " --> " + data[i][6]);
        }
    }

    public static String getInputFileName() {
        Scanner inp = new Scanner(System.in);
        String filename;
        System.out.print("File name of the student data? ");
        filename = inp.nextLine();
        //filename = "stuData2.txt";
        return filename.trim(); //Remove spaces before and after the filename
    }

    public static int getNumberOfStudentsInGroup() {
        Scanner inp = new Scanner(System.in);
        int result;
        System.out.print("How many students in a group? ");
        result = inp.nextInt();
        //result = 2;
        return result;
    }
}