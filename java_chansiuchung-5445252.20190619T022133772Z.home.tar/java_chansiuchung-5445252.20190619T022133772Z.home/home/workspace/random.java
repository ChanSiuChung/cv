import java.util.*; 

class characters 
{
    public static void main(String[] args)
    {
       Random generate = new Random();
       String[] name = {"John", "Marcus", "Susan", "Henry"};

       System.out.println("Customer: " + name[generate.nextInt(4)]); 
       System.out.println(generate.nextInt(4));

    }
}