class binary{
    public static void main(String[] args) {
        int arr[] = new int[]{1,3,6,8,11};
        int first, mid, last;
        boolean found = false;
        
        int target = -5;
        
        first = 0;
        last = arr.length - 1;
        mid = (last + first)/2;
        //System.out.println(last);
            
            int i = 0;
            first = 0;
            
            mid = (first + last)/2;
            found = false;
            
            while(first <= last && found == false){
                if(target == arr[mid]){
                    System.out.println("Yes");
                    found = true;
                }
                    
                if(target > arr[mid]){
                    first = mid + 1;
                }else{
                    last = mid - 1;
                }
                mid = (first + last)/2;
            }
            if(found == false){
                System.out.println("No");
            }
                
            //System.out.println(Qnumber);
        }
    }