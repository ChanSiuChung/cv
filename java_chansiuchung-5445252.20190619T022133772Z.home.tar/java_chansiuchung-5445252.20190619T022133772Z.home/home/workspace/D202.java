import java.util.Scanner;

    class q56 {
        public static void main (String args[]) {
            int a,b,d,e;
            int[] c;
            Scanner datain = new Scanner(System.in);
            a = datain.nextInt();
            b = a;
            d = a;
            e = a;
            a = a/2
            
            c = new int[e+1];
            while(d >= 0){
                c[d] = 0;
                d = d - 1;
            }
            while (a < b){
                if(2*a % b == 0){
                    System.out.println(2*a / b);
                    c[b] = b;
                    b    = b - 1;
                }else{
                    b = b - 1;
                }
            }
            while (e >= 0){
                if (c[e] > 0){
                    System.out.println(c[e]);
                    e = e - 1;
                }
            }
        }
    }
        
    