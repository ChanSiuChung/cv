import java.util.Scanner;

    class q55 {
        public static void main (String args[]) {
            int a;
            a = 1;
            while (a <= 100){
                if(a % 3 == 0 && a % 2 == 0){
                    System.out.println(a+"+*");
                    a = a + 1;
                }else if(a % 2 == 0){
                    System.out.println(a+"+");
                    a = a + 1;
                }else if(a % 3 == 0){
                    System.out.println(a+"*");
                    a = a + 1;
                }else{
                    System.out.println(a);
                    a = a + 1;
                }
            }
        }
    }