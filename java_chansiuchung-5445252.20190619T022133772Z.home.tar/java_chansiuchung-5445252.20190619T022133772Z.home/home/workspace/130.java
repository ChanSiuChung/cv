import java.util.Scanner;
    class date130{
        public static void main (String args[]) {
            Scanner di = new Scanner(System.in);
            int a, b, c, d, e;
            a = di.nextInt();
            c = 1;
            for(d = 1;d <= a;d++){
                for(b = d;b <= a + d - 1 ;b++){
                    System.out.print(b*b+  " ");
                }
                System.out.println(" ");
            }
        }
    }
    
    class date1302{
        public static void main (String args[]) {
            Scanner di = new Scanner(System.in);
            int a, b, c, d, e, f;
            a = di.nextInt();
            for(b = 1; b <= a; b++){
                f = 0;
                for(d = 1;d <= a;d++){
                    System.out.print(b * b+ f+ " ");
                    f = f +b;
                 }
                 System.out.println("");
             }
        }
    }
    
    class date1303{
        public static void main (String args[]) {
            Scanner di = new Scanner(System.in);
            int a, b, c, e, f;
            a = di.nextInt();
            f = 0;
            b = 1;
            e = b;
            for(; b <= a; b++){
                for(c = 1;c <= a;c++){
                    System.out.print(e +f +" ");
                    f = f + 4;
                }
                System.out.println("");
                f = f - 4;
            }
        }
    }