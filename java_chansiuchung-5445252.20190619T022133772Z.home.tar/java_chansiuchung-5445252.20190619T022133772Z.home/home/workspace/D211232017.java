import java.util.Scanner;

    class q2 {
        public static void main (String args[]) {
            Scanner datain = new Scanner(System.in);
            int input1, input2;
            input1 = datain.nextInt();
            input2 = datain.nextInt();
            while (input1 <= input2) {
                if (input1 % 3 == 0){
                    System.out.println(input1);
                    input1 = input1 + 1;
                }else{
                    input1 = input1 + 1;
                }
            
            }
        }
    }