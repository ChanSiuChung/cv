import java.util.Scanner;

class a7b{
    public static void main(String args[]) {
        double input1, input2, reslut;
        //taking value as command  line argument.
        Scanner datain = new Scanner(System.in);
        input1 = datain.nextInt();
        input2 = datain.nextInt();
        reslut = Math.pow(input1, input2);
        System.out.println(reslut);
    }
}