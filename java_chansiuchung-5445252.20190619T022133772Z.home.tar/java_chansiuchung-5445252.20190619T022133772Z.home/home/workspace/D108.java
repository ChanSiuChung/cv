import java.util.Scanner;
class d108{
    public static void main(String args[]){
        Scanner A = new Scanner(System.in);
        String c = "i love ict.!" ;
        System.out.println(c.charAt(1));
        System.out.println(c.length());
        System.out.println(c.substring(3,6));
    }
}