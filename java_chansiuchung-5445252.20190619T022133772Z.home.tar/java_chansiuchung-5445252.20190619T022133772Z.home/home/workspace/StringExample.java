class StringExample {
    public static void main(String args[]) {
        String a = "Hello";
        String b;
        String c, d;
        b = a;
        c = "Java Programming";
        d = new String("卢 \n毅研");
        System.out.println(c);
        System.out.println(d);
        }
    }