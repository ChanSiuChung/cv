import java.util.Scanner;
    class d301{
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            String a, b, c, d, e;
            a = di.nextLine();
            b = di.nextLine();
            c = di.nextLine();
            d = di.nextLine();
            e = di.nextLine();
            System.out.println(a + b + c + d + e);
        }
    }