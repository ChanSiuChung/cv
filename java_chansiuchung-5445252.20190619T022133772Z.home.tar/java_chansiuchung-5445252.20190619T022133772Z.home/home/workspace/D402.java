import java.util.Scanner;
    class d402{
        public static void main(String arg[]){
            //System.out.println("hi");
            Scanner di = new Scanner(System.in);
            Scanner ac = new Scanner(System.in);
            int N = di.nextInt();
            long data[] = new long [N];
            double price[] = new double [N];
            int i = 0;
            while(i < N){
                data[i] = di.nextLong();
                price[i] = di.nextDouble();
                i++;
            }
            
            
            int goods = di.nextInt();
            long code[] = new long[goods];
            for(int k = 0; k < goods; k++){
                code[k] = di.nextLong();
            }
            
            double count = 0;
            int z = 0;
            int j = 0;
            while(z < goods && j < N){
                    if(code[z] == data[j]){
                        count = count + price[j];
                        z++;
                        j =0;
                    }else{
                        j++;
                    //System.out.println("hah");
                    }
            }
            System.out.println(count);
        
        }
    }