import java.io.BufferedReader; 

import java.io.FileReader; 

import java.io.BufferedWriter; 

import java.io.FileWriter; 

import java.io.IOException; 

 

class task1a{ 

 

    public static void main(String[] args) throws IOException { 
    
     
    
        String fPath = "/home/ubuntu/workspace/task1a.txt"; 
        
        // read the content from file 
        
        BufferedReader br = new BufferedReader(new FileReader(fPath)); 
        
         
        int x = 1;
        
        String line = br.readLine(); 
        
        while(line != null) { 
            
            System.out.print("Line " + x+": ");
            
            System.out.println(line); 
            
            line = br.readLine(); 
            
            x++;
        
        } 
        
    } 

}