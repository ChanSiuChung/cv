```
-------------------------------------------------------------
 _____                           _     ___                  
/  __ \                         | |   |_  |                 
| /  \/ __ _ _ __ _ __ ___   ___| |     | | __ ___   ____ _ 
| |    / _` | '__| '_ ` _ \ / _ \ |     | |/ _` \ \ / / _` |
| \__/\ (_| | |  | | | | | |  __/ | /\__/ / (_| |\ V / (_| |
 \____/\__,_|_|  |_| |_| |_|\___|_| \____/ \__,_| \_/ \__,_|
-------------------------------------------------------------
```
Hi there! Welcome to Carmel ICT Java workspace on Cloud9 IDE!

To get you started, create some files, play with the terminal,
or visit http://docs.c9.io for our documentation.

To start programming in Java, follow the steps below:

1. Create a new file e.g first.java
2. Type in the program using the online editor and save the file.
3. Run the following command to translate (compile) your program into a binary program
    ~~~~
    javac first.java
    ~~~~
4. Run the program by the following command
    ~~~~
    java first
    ~~~~