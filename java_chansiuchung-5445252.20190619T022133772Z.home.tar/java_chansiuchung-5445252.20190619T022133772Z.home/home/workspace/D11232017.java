import java.util.Scanner;

    class q1 {
        public static void main (String args[]) {
            int input1;
            int input;
            Scanner datain = new Scanner(System.in);
            input1 = datain.nextInt();
            input = input1;
            System.out.println("Input a number:" + input1);
            input1 = (input1)-(input1)+1;
                while (input1 <= input ){
                    System.out.println(input1);
                    input1 = input1 +1;
                }
        }
    }