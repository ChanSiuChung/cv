class HKID {
    
    
    public static char a2c(int a) {
        char b = (char) (a);
        return b;
    }
    public static int c2a(char a) {
        int value = (int) a;
        return value;
    }
    
    public static char getCheckDigit(String prefix , String digits) {
        int dvalue=0, svalue=0, value = 0;
        int checkvalue = 0;
        char r;
    
        if (prefix.length() == 2) {
            svalue = (c2a(prefix.charAt(0)) - 55) * 9 ;
            svalue = svalue + (c2a(prefix.charAt(1)) - 55) * 8;
        } else if (prefix.length() == 1) 
            svalue = 36 * 9 + (c2a(prefix.charAt(0)) - 55) * 8;
    
        for (int i = 0; i < 6; i++) 
            dvalue = dvalue + (c2a(digits.charAt(i)) - 48) * (7 - i);
        
        value = svalue + dvalue;
        checkvalue = 11 - (value % 11);
    
        if (checkvalue == 10) 
            r = 'A';
        else if (checkvalue == 11) 
            r = '0';
        else 
            r = a2c(checkvalue + 48);

        return r;
    }

    
    public static void main(String[] args) {
        char r;
        String prefix, digits;
        java.util.Scanner b = new java.util.Scanner(System.in);
        boolean ppass = false;
        boolean ppass2 = false;
        int dpass = 0;
        int wrong = 0;
        
        do{
            //check which one is wrong and print reminder
            if(wrong != 0 && ppass == false && dpass != 6){
                System.out.println("prefix and digits input invalid, please input again");
            }else if(wrong != 0 && dpass != 6){
                System.out.println("digits input invalid, please input again");
            }else if(wrong != 0 && (ppass == false || ppass2 == false)){
                System.out.println("prefix input invalid, please input again");
            }
            
            ppass2 = false;
            ppass = false;
            
            System.out.print("Enter prefix: ");
            prefix = b.nextLine();
            System.out.print("Enter the digits: ");
            digits = b.nextLine();
            
            
            //check A - Z(prefix)
            if(prefix.length() == 2){
                if( (int)(prefix.charAt(0)) >= 65 && (int)(prefix.charAt(0)) <= 90 ){
                    ppass = true;

                    
                }
                if( (int)(prefix.charAt(1)) >= 65 && (int)(prefix.charAt(1)) <= 90 ){
                    ppass2 = true;
                    
                }
                
            }else if(prefix.length() == 1){
                for(int i = 0;i < 1;i++){
                    if( (int)(prefix.charAt(i)) >= 65 && (int)(prefix.charAt(i)) <= 90 ){
                        ppass = true;
                        ppass2 = true;
                    }
                }
            }
            //check (digits =6 or not)
            dpass = 0;
            if(digits.length() == 6){
                for(int j = 0;j < 6;j++){
                    if((int)(digits.charAt(j)) >= 48 && ((int)digits.charAt(j)) <= 57){
                        dpass++;
                    }
                }
            }
            
            
            wrong += 1; //wrong count
            
        }while(ppass == false || ppass2 == false || dpass != 6);
    
            // Complete your data validation here.
            // Ensure that if the inputs are not valid, ask them to input again
            // Examples of invalid input:
            // n 123456
            // 9 123456
            // H 1234567
            // Y 12AB76
            // Y2 123456



        r = getCheckDigit(prefix, digits);
        System.out.println("The check digit is " + r  ) ;
    }

}