class methods1{ 
    public static void main(String[] args) { 
        int n ;
        double h;
        a(); 
        b();
        n = c();
        h = d();
        System.out.println(n);
        System.out.println(h);
    } 
    
    public static void a() { 
        System.out.println(3); 
    } 

    public static void b() { 
        System.out.println(2); 
    }

    public static int c() { 
        int result;
        result = 32111;
        return result;
    }
    
    public static double d(){
        double result1;
        result1 = 56.3;
        return result1;
    }
} 