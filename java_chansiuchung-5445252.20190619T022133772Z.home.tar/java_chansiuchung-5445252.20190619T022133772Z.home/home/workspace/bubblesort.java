class bubblesort {

    public static void main(String args[]) {
        int[] data = new int[]{35, 30, 40, 50, 60, 89};
        int min, minpos, temp;
        boolean ascen = true;
        
        //before sorting
        for (int i=0 ; i<6; i++) {
            System.out.print(data[i] + " ");
        }
        System.out.println();
        int j = 0;
        //sort
        while( j < 5 && ascen){
            //push largest to last
            for(int i = 0; i < 5 - j;i++){
                if(data[i] > data[i + 1]){
                    temp = data[i];
                    data[i] = data[i + 1];
                    data[i + 1] = temp;
                    ascen = false;
                }
            }
            j++;
        }
        
        //After sorting
        for (int i=0 ; i<6; i++) {
            System.out.print(data[i] + " ");
        }
        System.out.println();
    

    }

}