import java.util.Scanner;

     class d105 {
         public static void main (String args[]) {
             Scanner datain = new Scanner(System.in);
             int y, m, d, y2, m2, d2;
             y = datain.nextInt();
             m = datain.nextInt();
             d = datain.nextInt();
             y2 = datain.nextInt();
             m2 = datain.nextInt();
             d2 = datain.nextInt();
             if (y > y2){
                 System.out.println("After");
             }else if (y < y2){
                 System.out.println("Before");
             }else if (m > m2){
                 System.out.println("After");
             }else if (m < m2){
                 System.out.println("Before");
             }else if (d > d2){
                 System.out.println("After");
             }else if (d < d2){
                 System.out.println("Before");
             }else System.out.println("Same");
             }
         }