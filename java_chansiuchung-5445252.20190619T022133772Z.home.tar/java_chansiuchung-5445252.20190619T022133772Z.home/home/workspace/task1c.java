import java.io.BufferedReader; 

import java.io.FileReader; 

import java.io.BufferedWriter; 

import java.io.FileWriter; 

import java.io.IOException; 

 

class task1c{ 

 

    public static void main(String[] args) throws IOException { 
    
     
    
        String fPath = "/home/ubuntu/workspace/task1c_1.txt"; 
        
        // read the content from file 
        
        BufferedReader br = new BufferedReader(new FileReader(fPath)); 
        
         
        int x= 0;
        
        String[] sa = new String[30];
        for(int j = 0; j<30;j++){
            sa[j] = "";
        }
        
        String line = br.readLine(); 
        
        while(line != null) { 

            line = br.readLine(); 
            
            sa[x] = line;
            
            x++;
        
        }
        for(int k = 29; k > 0; k--){
            if(sa[k] != "" &&  sa[k] != null){
                System.out.println(sa[k]);
            }
        }
        
    } 

}