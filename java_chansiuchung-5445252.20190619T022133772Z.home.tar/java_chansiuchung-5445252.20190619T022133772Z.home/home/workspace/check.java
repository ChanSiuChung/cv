import java.util.Scanner;

    class check {
        public static void main (String args[]) {
            Scanner datain = new Scanner(System.in);
            double a;
            a = datain.nextDouble();
            if (a > 0) {
                System.out.println("it is a positive number");
            }else if (a == 0) {
                System.out.println("it is 0");
            }else System.out.println("it is a negative number");
        
    }
}
