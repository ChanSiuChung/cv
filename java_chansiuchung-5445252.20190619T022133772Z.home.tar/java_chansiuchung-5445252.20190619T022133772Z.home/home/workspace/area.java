import java.util.Scanner;

class area{
    public static void main(String args[]) {
        int a, b, C;
        double reslut, d;
        Scanner datain = new Scanner(System.in);
        a = datain.nextInt();
        b = datain.nextInt();
        C = datain.nextInt();
        double radians = Math.toRadians(C);
        reslut = Math.sin(radians)*a*b / 2 ;
        d = Math.round(reslut * 1000);
        System.out.println(d / 1000);
    }
}
