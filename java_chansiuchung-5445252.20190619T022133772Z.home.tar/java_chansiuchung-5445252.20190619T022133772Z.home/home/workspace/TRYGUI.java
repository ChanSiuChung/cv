package gui;
import javax.swing.*;
import java.awt.*;

class GUI{
    
    public static void main(String[] args){
        JFrame frame = new JFrame();
        
        
        
        frame.setSize(new Dimension(500, 400));
        
        frame.setLocationRelativeTo(null);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setTitle("A simple JFrame");
        frame.setResizable(false);
        frame.setVisible(true);
    }
}