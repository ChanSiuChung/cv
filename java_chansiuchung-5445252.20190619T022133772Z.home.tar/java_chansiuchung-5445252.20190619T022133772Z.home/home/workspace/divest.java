   class divtest {
        public static void main (String args[]) {
            int a, b;
            double c;
            a = 10;
            b = 4;
            /*can use c = (double) a / b;to prevent c become an int
            (double) is type casting*/
            c = a / b;
            System.out.println(c);
        }
    }