import java.util.Scanner;
class exam2{
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            int m = di.nextInt();
            boolean P = checkbox(m);
            int[][] solution = new int[9][9];
            

        }
        
        public static boolean checkbox(int n){
            int n = di.nextInt();
            int[] tmp = new int[9];
            for(int i = 0;i<3;i++){
                for (int j = 0; j <3;j++){
                    int a = (n/3)*3;
                    int b = (n%3)*3;
                    tmp[i*3 +j]= solution[a + i][b + j];
                }
            }
            for(int z=0;z<9;z++){
                for(int k = 0;k<8;k++){
                    if(tmp[k] ==tmp[k + 1]){
                        return false;
                    }else{
                        int swit = tmp[k];
                        tmp [k] = tmp[k+1];
                        tmp[k+1] = swit;
                    }
                }
            }
            return true;
        }
}