import java.util.Scanner;
    class tttnew{
        public static void main (String args[]) {
            Scanner di = new Scanner(System.in);
            int a, b, c, choice, e, f, g, h, x, y;
            char z;
            boolean flag, flag2, flag3;
            char[][] array = new char[3][3];
            e = 0;
            flag = true;
            flag2 = true;
            //main body
            while (e == 0){
                //starting page
                System.out.println("========================================================");
                System.out.println("HELLO, Welcome to TIC-TAC-TOE");
                System.out.println("Press");
                System.out.println("1. Start the game");
                System.out.println("2. Rules");
                System.out.println("3. Exit");
                System.out.println("========================================================");
                choice = di.nextInt();
                while( choice != 1 && choice != 2 && choice != 3){
                    System.out.println("invalid input, please try again");
                    System.out.println("========================================================");
                    System.out.println("HELLO, Welcome to TIC-TAC-TOE");
                    System.out.println("Press");
                    System.out.println("1. Start the game");
                    System.out.println("2. Rules");
                    System.out.println("3. Exit");
                    System.out.println("========================================================");
                    choice = di.nextInt();
                    }
                if(choice == 3){
                    System.out.println("BYE!");
                    System.exit(0);
                }else if(choice == 2){
                    System.out.println("Get 3 in a row, each person must switch taking turns, first X, then O.");
                    System.out.println("3 letters must all connect in a straight line in one direction, up or down, left or right, or diagonally.");
                }else{
                    for(a = 0;a < 3;a++){
                        for(b =0;b < 3;b++){
                            array[a][b] = '.';
                        }
                    }
                }
                bodyloop:
                for(c = 0;c <= 5;c++){
                    for(g = 0;g == 0;){
                        h = 0;
                        //check loop for X
                        checkloop:
                        do{
                            System.out.println("Player X's turn, please enter x-axis of X you want to put:");
                            x = di.nextInt();
                            x = x - 1; 
                            System.out.println("Player X's turn, please enter y-axis of X you want to put:");
                            y = di.nextInt();
                            y = y - 1;
                            if (y > 2 || y < 0|| x > 2|| x <0){
                                System.out.println("ERROR, please try again");
                                break checkloop;
                            }else if(array[y][x] != '.'){
                                System.out.println("ERROR, please try again");
                                break checkloop;
                            }else{
                                array[y][x] = 'X';
                            for(a = 0;a < 3;a++){
                                for(b =0;b < 3;b++){
                                    if(b != 2){
                                        System.out.print(array[a][b]);
                                    }else{
                                        System.out.println(array[a][b]);
                                    }
                                }
                            }
                            h = h + 1;
                            g = g + 1;
                            }
                        }while( h == 0);
                    }
                    //
                    //
                    //check XXXXXXX
                    //check horiz
                    for(x = 0;x < 3;x++){
                        for(y = 0;y < 3;y++){
                            if(array[y][x] == 'X'){
                                flag = true;
                            }else{
                                flag = false;
                            }
                            if (flag == false){
                                break;
                            }
                        }
                        if (flag == true){
                            System.out.println("X wins");
                            System.out.println("Press");
                            System.out.println("1. Next match");
                            System.out.println("2. End game");
                            f = di.nextInt();
                            if(f == 2){
                                System.exit(0);
                            }else if(f == 1){
                                break bodyloop;
                            }
                        }
                    }
                    //vertical
                    for(y = 0;y < 3;y++){
                        for(x = 0;x < 3;x++){
                            if(array[y][x] == 'X'){
                                flag = true;
                            }else{
                                flag = false;
                            }
                            if (flag == false){
                                break;
                            }
                        }
                        if (flag == true){
                            System.out.println("X wins");
                            System.out.println("Press");
                            System.out.println("1. Next match");
                            System.out.println("2. End game");
                            f = di.nextInt();
                            if(f == 2){
                                System.exit(0);
                            }else if(f == 1){
                                break bodyloop;
                            }
                        }
                    }
                    //diagonal1
                    for(y = 0; y < 3;y++){
                        if (array[y][y] == 'X'){
                            flag = true;
                        }else{
                            flag = false;
                        }
                        if(flag == false){
                            break;
                        }
                    }
                    if (flag == true){
                        System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        f = di.nextInt();
                        if(f == 2){
                            System.exit(0);
                        }else if(f == 1){
                            break bodyloop;
                        }
                    }
                    //diagonal2
                    y = 0;
                    for(x = 2;x >= 0;x--){
                        if(array[y][x] == 'X'){
                            flag = true;
                        }else{
                            flag = false;
                        }
                        if(flag == false){
                            break;
                        }
                        y++;
                    
                    }
                    if(flag == true){
                        System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        f = di.nextInt();
                        if(f == 2){
                            System.exit(0);
                        }else if(f == 1){
                            break bodyloop;
                        }
                    }
                    
                    //check loop for Y
                    //
                    //
                    //
                    for(g = 0;g == 0;){
                        h = 0;
                        checkloop2:
                        do{
                            System.out.println("Player O's turn, please enter x-axis of O you want to put:");
                            x = di.nextInt();
                            x = x - 1; 
                            System.out.println("Player O's turn, please enter y-axis of O you want to put:");
                            y = di.nextInt();
                            y = y - 1;
                            if (y > 2 || y < 0|| x > 2|| x <0){
                                System.out.println("ERROR, please try again");
                                break checkloop2;
                            }else if(array[y][x] != '.'){
                                System.out.println("ERROR, please try again");
                                break checkloop2;
                            }else{
                                array[y][x] = 'O';
                            for(a = 0;a < 3;a++){
                                for(b =0;b < 3;b++){
                                    if(b != 2){
                                        System.out.print(array[a][b]);
                                    }else{
                                        System.out.println(array[a][b]);
                                    }
                                }
                            }
                            h = h + 1;
                            g = g + 1;
                            }
                        }while( h == 0);
                    }
                    //check OOOOO
                    //check hori
                    for(x = 0;x < 3;x++){
                        for(y = 0;y < 3;y++){
                            if(array[y][x] == 'O'){
                                flag2 = true;
                            }else{
                                flag2 = false;
                            }
                            if (flag2 == false){
                                break;
                            }
                        }
                        if (flag2 == true){
                            System.out.println("O wins");
                            System.out.println("Press");
                            System.out.println("1. Next match");
                            System.out.println("2. End game");
                            f = di.nextInt();
                            if(f == 2){
                                System.exit(0);
                            }else if( f == 1){
                                break bodyloop;
                            }
                        }
                    }
                    //check vertical
                    for(y = 0;y < 3;y++){
                        for(x = 0;x < 3;x++){
                            if(array[y][x] == 'O'){
                                flag2 = true;
                            }else{
                                flag2 = false;
                            }
                            if (flag2 == false){
                                break;
                            }
                        }
                        if (flag2 == true){
                            System.out.println("O wins");
                            System.out.println("Press");
                            System.out.println("1. Next match");
                            System.out.println("2. End game");
                            f = di.nextInt();
                            if(f == 2){
                                System.exit(0);
                            }else if (f == 1){
                                break bodyloop;
                            }
                        }
                    }
                    //diagonals1
                    for(y = 0; y < 3;y++){
                        if (array[y][y] == 'O'){
                            flag2 = true;
                        }else{
                            flag2 = false;
                        }
                        if(flag2 == false){
                            break;
                        }
                    }
                    if (flag2 == true){
                        System.out.println("O wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        f = di.nextInt();
                        if(f == 2){
                            System.exit(0);
                        }else if(f == 1){
                            break bodyloop;
                        }
                    }
                    //diagonal2
                    y = 0;
                    for(x = 2;x >= 0;x--){
                        if(array[y][x] == 'O'){
                            flag2 = true;
                        }else{
                            flag2 = false;
                        }
                        if(flag2 == false){
                            break;
                        }
                        y++;
                    }
                    if(flag2 == true){
                        System.out.println("O wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        f = di.nextInt();
                        if(f == 2){
                            System.exit(0);
                        }else if(f == 1){
                            break bodyloop;
                        }
                    }
                    
                }
            }
        }
    }