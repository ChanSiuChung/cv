import java.util.Scanner;
    
    class a11222017 {
        public static void main (String args[]) {
        double a, b, c, d;
        Scanner datain = new Scanner(System.in);
        System.out.println("Number of daytime minutes?");
        a = datain.nextDouble();
        System.out.println("Number of evening minutes?");
        b = datain.nextDouble();
        System.out.println("Number of weekend minutes?");
        c = datain.nextDouble();
        //System.out.println(a + b + c);
        d = a;
        if (a > 100){
            a = (a-100)*0.25+b*0.15+c*0.2;
        }else{
            a = b*0.15+c*0.2;
        }
        if (d > 250){
            d = (d - 250)*0.45+b*0.35+c*0.25;
        }else{
            d = b*0.35+c*0.25;
        }
        a = Math.round(a * 100);
        a = a/100;
        d = Math.round(d * 100);
        d = d/100;

        if (a > d){
            System.out.println("Plan A costs" + a);
            System.out.println("Plan B costs" + d);
            System.out.println("Plan B is cheapest");
        }else if (a < d){
            System.out.println("Plan A costs" + a);
            System.out.println("Plan B costs" + d);
            System.out.println("Plan A is cheapest");
        }else {
            System.out.println("Plan A costs" + a);
            System.out.println("Plan B costs" + d);
            System.out.println("Plan A and B are the same price");
        }
        
    }
}