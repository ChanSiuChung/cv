import java.util.Scanner;
    class ttt3{
        public static void main (String args[]) {
            //check horiz
            for(x = 0;x < 3;x++){
                for(y = 0;y < 3;y++){
                    if(array[y][x] == 'X'){
                        flag = true;
                    }else{
                        flag = false;
                    }
                    if (flag == false){
                        break;
                    }
                }
                if (flag == true){
                        System.out.println("X wins");
                        break;
                }
            }
            //vertical
            for(y = 0;y < 3;y++){
                for(x = 0;x < 3;x++){
                    if(array[y][x] == 'X'){
                        flag = true;
                    }else{
                        flag = false;
                    }
                    if (flag == false){
                        break;
                    }
                }
                if (flag == true){
                        System.out.println("X wins");
                        break;
                }
            }
            //diagonals l to r
                for(y = 0; y < 3;y++){
                    if (array[y][y] == 'X'){
                        flag == true;
                    }else{
                        flag == false;
                    }
                    if(flag == false){
                        break;
                    }
                }
                if (flag == true){
                    System.out.println("X wins");
                }
            // r to l
            for(y = 0; y < 3;y++){
                x = 2;
                if(array[y][x] == 'X'){
                    flag = true;
                }else{
                    flag = false
                }
                if(flag == false){
                    break;
                }
                x--;
            }
            if(flag == true){
                System.out.println("X wins");
            }   
        }
    }