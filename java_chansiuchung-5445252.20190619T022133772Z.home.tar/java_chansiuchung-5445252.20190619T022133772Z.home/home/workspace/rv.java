import java.util.Scanner;

    class rv{
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            int i;
            String ori;
            ori = di.nextLine();
            for (i = 0;i < ori.length();i++) {
                if(ori.charAt(i)!='a' && ori.charAt(i)!='e' && ori.charAt(i)!='i' && ori.charAt(i)!='o' && ori.charAt(i)!='u' && ori.charAt(i)!='A' && ori.charAt(i)!='E' && ori.charAt(i)!='I' && ori.charAt(i)!='O' && ori.charAt(i)!='U'){
                    System.out.print(ori.charAt(i));
                }
            }
        }
    }