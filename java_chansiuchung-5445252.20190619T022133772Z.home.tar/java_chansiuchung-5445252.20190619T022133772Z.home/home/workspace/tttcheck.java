import java.util.Scanner;
    class tttcheck{
        public static void main (String args[]) {
            //check horiz
            for(x = 0;x < 3;x++){
                for(y = 0;y < 3;y++){
                    if(array[y][x] == 'O'){
                        flag2 = true;
                    }else{
                        flag2 = false;
                    }
                    if (flag2 == false){
                        break;
                    }
                }
                if (flag2 == true){
                        System.out.println("O wins");
                        System.exit(0);
                        break;
                }
            }
                //vertical
                for(y = 0;y < 3;y++){
                    for(x = 0;x < 3;x++){
                        if(array[y][x] == 'O'){
                            flag2 = true;
                        }else{
                            flag2 = false;
                        }
                        if (flag2 == false){
                            break;
                        }
                    }
                    if (flag2 == true){
                            System.out.println("O wins");
                            System.exit(0);
                            break;
                    }
                }
                    //diagonals l to r
                    for(y = 0; y < 3;y++){
                        if (array[y][y] == 'O'){
                            flag2 = true;
                        }else{
                            flag2 = false;
                        }
                        if(flag2 == false){
                            break;
                        }
                    }
                    if (flag2 == true){
                        System.out.println("O wins");
                        System.exit(0);
                    }
                // r to l
                //ERROR OCCUR
                y = 0;
                for(x = 2;x >= 0;x--){
                        if(array[y][x] == 'O'){
                            flag2 = true;
                        }else{
                            flag2 = false;
                        }
                        if(flag2 == false){
                            break;
                        }
                        y++;
                    
                }
                if(flag2 == true){
                    System.out.println("O wins");
                    System.exit(0);
                }   
        }
    }