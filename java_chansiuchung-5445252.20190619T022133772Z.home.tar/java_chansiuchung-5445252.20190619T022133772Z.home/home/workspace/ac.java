import java.util.Scanner;
    class ac{
        public static int[][] BD = new int[6][7];
        public static int[] TOPC = {5,5,5,5,5,5,5};
        public static int current_state = 3;
        public static int player = 1;
        
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            //int board
            boolean winc = false;
            for(int i = 0; i <=  5; i++){
                for(int j = 0; j <= 6 ; j++){
                    BD[i][j] =  0;
                }
            }
            
            do{
                //clear the choice
                int row = 0;
                int col = 0;
                //printboard
                printboard();
                //player choice
                if(player == 1){
                    for(int errordet = 0; errordet == 0;){
                        System.out.println("player A pls enter: {Row}{Column} :");
                        for(int m = 0;m == 0;){
                            row = di.nextInt();
                            col = di.nextInt();
                            if(row < 6 && row >= 0 && col < 7 && col >= 0){
                                m += 1;
                            }else{
                                System.out.println("Please input a valid nunber");
                            }
                        }
                        if(TOPC(row, col) == 1){
                            fill(row,col);
                            TOPC[col] -= 1;
                            player = 2;
                            errordet = 1;
                        }else{
                            System.out.println("An error occur, please input it again");
                        }
                        
                    }
                }else if(player == 2){
                    for(int errordet = 0; errordet == 0;){
                        System.out.println("player B pls enter: {Row}{Column} :");
                        for(int m = 0;m == 0;){
                            row = di.nextInt();
                            col = di.nextInt();
                            if(row < 6 && row >= 0 && col < 7 && col >= 0){
                                m += 1;
                            }else{
                                System.out.println("Please input a valid nunber");
                            }
                        }
                        if(TOPC(row, col) == 1){
                            fill(row,col);
                            TOPC[col] -= 1;
                            player = 1;
                            errordet = 1;
                        }else{
                            System.out.println("An error occur, please input it again");
                        }
                    }
                }
                //checkwin
                int winner;
                current_state = checkrowwin(row, col);
                if(current_state != 3){
                    winc = true;
                }
                current_state = checkcolwin(row, col);
                if(current_state != 3){
                    winc = true;
                }
                current_state = checkdiagwin1(row, col);
                if(current_state != 3){
                    winc = true;
                }
                current_state = checkdiagwin2(row, col);
                if(current_state != 3){
                    winc = true;
                }
                
                //check draw
                int drawcheck = 0;
                for(int i = 0; i <=6; i++){
                    if(TOPC[i] == -1){
                        drawcheck += 1;
                    }
                }
                if(drawcheck == 7){
                    current_state = 0;
                }

                
            
            }while(current_state == 3 && winc == false);
            
            if(current_state == 2){
                System.out.println("*************");
                System.out.println("player 1 win");
                System.out.println("*************");
                printboard();
            }else if(current_state == 1){
                System.out.println("*************");
                System.out.println("player 2 win");
                System.out.println("*************");
                printboard();
            }else if(current_state == 0){
                System.out.println("*************");
                System.out.println("draw");
                System.out.println("*************");
            }
        }
            //print win
    
    
        public static void printboard(){
            for(int i = 0; i <= 5 ; i++){
                System.out.print(i + " ");
                for(int j = 0; j <= 6 ; j++){
                    if(BD[i][j] == 0){
                        System.out.print(" []" + " ");
                    }else if(BD[i][j] == 1){
                        System.out.print(" "+ " O" + " ");
                    }else if(BD[i][j] == 2){
                        System.out.print(" "+ " X" + " ");
                    }
                }
                System.out.println("");
            }
            System.out.print(" ");
            for(int i = 0; i < 7; i++){
                System.out.print("   "+ i + "");
            }
            System.out.println("");
        }
        
        public static void fill(int row,int col){
            BD[row][col] = player;
        }
        
        public static int checkrowwin(int row, int col){
            int win = 1;
            for(int i = 0; i <= 3; i++){
                if(BD[row][i] != 0){
                    if(BD[row][i] == BD[row][i + 1] && BD[row][i] == BD[row][i + 2] && BD[row][i] == BD[row][i + 3]){
                        win += 3; 
                    }
                }
            }
            if (win == 4){
                current_state = player;
                int winner = player;
                return player;
            }else{
                win = 1;
                return 3;
            }
        }
        
        public static int checkcolwin(int row, int col){
            int win = 1;
            for(int i = 0; i < 4 ; i++){
                if(BD[i][col] != 0){
                    if(BD[i][col] == BD[i + 1][col] && BD[i][col] == BD[i + 2][col] && BD[i][col] == BD[i + 3][col]){
                        win += 3;
                    }
                }
            }
            if (win == 4){
                current_state = player;
                int winner = player;
                return player;
            }else{
                win = 1;
                return 3;
            }
        }
        
        public static int checkdiagwin1(int row , int col){
            int win = 1;
            ha:
            for(int j = 5; j >= 3 ;j--){
                for(int i = 0; i <= 3; i++){
                    if(BD[j][i] != 0){
                        if(BD[j][i] == BD[j - 1][i + 1] && BD[j][i] == BD[j - 2][i + 2] && BD[j][i] == BD[j - 3][i + 3]){
                            win += 3;
                            break ha;
                        }
                    }
                }
            }
            if (win == 4){
                current_state = player;
                int winner = player;
                return player;
            }else{
                win = 1;
                return 3;
            }
            
        }
        
        public static int checkdiagwin2(int row , int col){
            int win = 1;
            ha:
            for(int j = 5; j >= 3 ;j--){
                for(int i = 6; i >= 3; i--){
                    if(BD[j][i] != 0){
                        if(BD[j][i] == BD[j - 1][i - 1] && BD[j][i] == BD[j - 2][i - 2] && BD[j][i] == BD[j - 3][i - 3]){
                            win += 3;
                            break ha;
                        }
                    }
                }
            }
            if (win == 4){
                current_state = player;
                int winner = player;
                return player;
            }else{
                win = 1;
                return 3;
            }
            
        }
        
        public static int TOPC(int row, int col){
            if(TOPC[col] != row){
                return 0;
            }else{
                return 1;
            }
        }
    }