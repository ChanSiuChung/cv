import java.util.Scanner;
    class bs {
        public static void main(String args[]){
            int x = (1 + 0)/2;
            System.out.print(x);
        }
    }