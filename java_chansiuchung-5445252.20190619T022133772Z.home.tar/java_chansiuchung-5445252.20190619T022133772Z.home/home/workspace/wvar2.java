import java.util.Scanner;

class wvar2{
    public static void main(String args[]) {
        double a, b, c;
        //taking value as command  line argument.
        Scanner datain = new Scanner(System.in);
        a = datain.nextDouble();
        b = datain.nextDouble();
        c = datain.nextDouble();
        System.out.println(a+b+c);
    }
}