import java.util.Scanner;
    class bins {
        public static int[] data = new int[]{145,4356,476,9867,868,143,5476,68,8487,1714,1517,1947};
        public static void main(String args[]) {
            //generate a array
            Scanner di = new Scanner(System.in);
            System.out.println("what is the number you want to find?");
            int number = di.nextInt();
            bubblesort();
            int key;
            if()
            
    }
    
    public static void bubblesort(){
        int min, minpos, temp;
        boolean ascen = true;
        
        //before sorting
        for (int i=0 ; i<12; i++) {
            System.out.print(data[i] + " ");
        }
        System.out.println();
        int j = 0;
        //sort
        while( j < 11 && ascen){
            ascen = false;
            //push largest to last
            for(int i = 0; i < 11 - j;i++){
                if(data[i] > data[i + 1]){
                    temp = data[i];
                    data[i] = data[i + 1];
                    data[i + 1] = temp;
                    ascen = true;
                }
            }
            j++;
        }
        
        //After sorting
        for (int i=0 ; i<12; i++) {
            System.out.print(data[i] + " ");
        }
        System.out.println();
    }
}