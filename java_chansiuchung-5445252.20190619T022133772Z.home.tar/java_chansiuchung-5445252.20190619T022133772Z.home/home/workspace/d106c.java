import java.util.Scanner;

     class d106c {
         public static void main (String args[]) {
             Scanner datain = new Scanner(System.in);
             int A;
             A = datain.nextInt();
             if(A >= 100){
                 if(A % 100 == 11){
                     System.out.println(A+"th");
                 }else if(A % 100 == 12){
                     System.out.println(A+"th");
                 }else if(A % 100 == 13){
                     System.out.println(A+"th");
                 }else{
                     if(A % 10 == 1){
                        System.out.println(A+"st");
                    }else if(A % 10 == 2){
                        System.out.println(A+"nd");
                    }else if (A % 10 == 3){
                        System.out.println(A+"rd");
                    }else{
                        System.out.println(A+"th");
                    }
                }
            }else{
                if (A == 11){
                    System.out.println(A+"th");
                }else if (A == 12){
                    System.out.println(A+"th");
                }else if (A == 13){
                    System.out.println(A+"th");
                }else if(A % 10 == 1 || A == 1){
                    System.out.println(A+"st");
                }else if(A % 10 == 2 || A == 2){
                    System.out.println(A+"nd");
                }else if(A % 10 == 3 || A == 3){
                    System.out.println(A+"rd");
                }else{
                    System.out.println(A+"th");
                }
            }
        }
     }