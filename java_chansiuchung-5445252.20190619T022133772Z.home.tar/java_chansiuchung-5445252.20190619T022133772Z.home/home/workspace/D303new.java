import java.util.Scanner;
    class d303n{
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            String reverse = "";
            String input = "";
            input = di.nextLine();
            for(int i = input.length() - 1; i >= 0; i--){
                reverse = reverse + input.charAt(i);
            }
            if(input.compareTo(reverse) == 0){
                System.out.println(reverse);
                System.out.println("Yes");
            }else{
                System.out.println(reverse);
                System.out.println("No");
            }
        }
    }