import java.util.Scanner;
    class decrypt{
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            System.out.println("Enter /n 1 = Encrypt /n 2 = Decrypt");
            int choice = di.nextInt();
            System.out.println("What is the non-decrypted message?");
            String message = di.nextLine();
            System.out.println("What is the password?");
            int secret = di.nextInt();
            if(choice == 1){
                String result = encrypt1(message,secret);
            }else if{choice == 2){
                
            }
            }
            System.out.println(result);
        }
    
    
        public static String decrypt1(String inp,int secret){
            String ret = "";
            int temp;
            for (int i = 0; i<inp.length(); i++){
                temp = 0;
                if (( (int)inp.charAt(i) ) >= 97 && ((int)inp.charAt(i) ) <= 122) {
                    temp = ((inp.charAt(i)) - secret);
                    if ( temp <= 122- 26 ){
                        temp = temp + 26;
                    }
                    
                }else if(( (int)inp.charAt(i) ) >= 65 && ((int)inp.charAt(i) ) <= 90) {
                    temp = ((inp.charAt(i)) + secret);
                    if ( temp <= 90- 26){
                        temp = temp + 26;
                    }
                }else{
                    temp = inp.charAt(i);
                }
                
                ret = ret + ((char)temp);
            }
            return ret;
        }
    }