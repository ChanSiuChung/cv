import java.util.Scanner;
    class d801{
        public static void main(String args[]){
            Scanner di = new Scanner(System.in);
            int N = di.nextInt();
            int Q = di.nextInt();
            //System.out.println(N);
            int[] Narr = new int[N];

            

            for(int i = 0;i < N;i++){
                Narr[i] = di.nextInt();
            }
            
            
            int first, mid, last;
            boolean found = false;
            first = 0;
            last = N - 1;
            mid = (first + last)/2;
            
            int i = 0;
            while(i < Q){
                first = 0;
                last = N - 1;
                mid = (first + last)/2;
                found = false;
                int target = di.nextInt();
                
                while(first <= last && found == false){
                    if(target == Narr[mid]){
                        System.out.println("Yes");
                        found = true;
                    }
                    
                    if(target > Narr[mid]){
                        first = mid + 1;
                    }else{
                        last = mid - 1;
                    }
                    mid = (first + last)/2;
                }
                if(found == false){
                    System.out.println("No");
                }
                
                i++;
                
            
                //System.out.println(Qnumber);
            }
        }
    }