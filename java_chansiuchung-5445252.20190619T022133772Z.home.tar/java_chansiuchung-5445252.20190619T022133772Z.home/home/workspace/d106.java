import java.util.Scanner;

     class d106 {
         public static void main (String args[]) {
             Scanner datain = new Scanner(System.in);
             int A;
             A = datain.nextInt();
             if (A < 100){
                 if(A == 1 || A == 21){
                     System.out.println(A+"st");
                 }else if(A == 2 || A == 22){
                     System.out.println(A+"nd");
                 }else if (A == 3 || A == 23){
                     System.out.println(A+"rd");
                 }else{
                     System.out.println(A+"th");
                 }
             }else{
             if ( A % 100 == 1 || A % 100 == 21){
                 System.out.println(A + "st");
             }else if (A % 100 == 2 || A % 100 == 22){
                 System.out.println(A + "nd");
             }else if (A % 100 == 3 || A % 100 == 23){
                 System.out.println(A + "rd");
             }else{
                System.out.println(A +"th");
             } 
         }
    }
}