import java.util.Scanner;

    class arraytest {
        public static void main (String args[]) {
        Scanner datain = new Scanner(System.in);
        int[] a;
        int b;
        b = 3;
        a = new int[b];
        a[0] = 1;
        a[1] = 2;
        a[2] = 3;
        System.out.println(a[0]);
        System.out.println(a[1]);
        System.out.println(a[2]);
        }
    }