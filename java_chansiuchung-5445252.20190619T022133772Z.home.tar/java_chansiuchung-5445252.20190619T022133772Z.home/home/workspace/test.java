import java.util.Scanner;
   class test{

         public static void main(String args[]) {
         String Str = new String("Welcome to Tutorialspoint.com");

         System.out.print("Return Value :" );
         //System.out.println(Str.toCharArray() );
         
         char[] d = Str.toCharArray();
         System.out.println(Str.charAt(5));
         System.out.println(d[7]);
      //String c = new String("popop");
         //char[] b = new char[c];/*String str1 = "Strings are immutable";
         /*String str2 = new String("Strings are immutable");
         String str3 = new String("Integers are not immutable");
      
         int result = str1.compareTo( str2 );
         System.out.println(result);
      
         result = str2.compareTo( str3 );
         System.out.println(result);
         
         int c = str2.length();
         System.out.println(c);*/
         }
   

      /*
      char[] helloArray = { 'h', 'e', 'l', 'l', 'o', '.' };
      String hello = new String(helloArray);
      String haha = "haha";
      hello = hello.concat(haha);
      System.out.println(hello);
      int floatVar = 3 ;
      int intVar = 3;
      int stringVar = 3; 
      
      String helloString = new String(helloArray);  
      System.out.println( helloString );
      */
   }