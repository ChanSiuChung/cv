import java.util.Scanner;
    class ttt2{
        public static void main (String args[]) {
            Scanner di = new Scanner(System.in);
            int a, b, c, choice;
            char[][] array = new char[3][3];
            //input 0 into all array
            for(a = 0;a < 3;a++){
                for(b =0;b < 3;b++){
                    array[a][b] = '.';
                }
            }
            //the main body
            //X turn
            int x, y;
            char z;
            c = 1;
            do{
                System.out.println("Player X's turn, please enter x-axis of X you want to put:");
                x = di.nextInt();
                x = x - 1; 
                System.out.println("Player X's turn, please enter y-axis of X you want to put:");
                y = di.nextInt();
                y = y - 1;
                //do sorting and print and check
                array[y][x] = 'X';
                for(a = 0;a < 3;a++){
                    for(b =0;b < 3;b++){
                        if(b != 2){
                            System.out.print(array[a][b]);
                        }else{
                            System.out.println(array[a][b]);
                        }
                    }
                }
                System.out.println("Player Y's turn, please enter x-axis of O you want to put:");
                x = di.nextInt();
                x = x - 1;
                System.out.println("Player Y's turn, please enter y-axis of O you want to put:");
                y = di.nextInt();
                y = y - 1;
                //do sorting and print and check
                array[y][x] = 'O';
                for(a = 0;a < 3;a++){
                    for(b =0;b < 3;b++){
                        if(b != 2){
                            System.out.print(array[a][b]);
                        }else{
                            System.out.println(array[a][b]);
                        }
                    }
                }
                c++;
            }while (c < 9);
            //////
            //////
            ///////
            //
            if( array[0][0] == 'X' && array[1][0] =='X' && array[2][0] == 'X' ){
                System.out.println("X wins");
            }
        }
    }