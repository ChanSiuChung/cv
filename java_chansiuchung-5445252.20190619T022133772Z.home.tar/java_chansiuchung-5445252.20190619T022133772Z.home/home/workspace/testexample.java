import java.util.Scanner;
    class examex{
        public static void main (String args[]) {
             Scanner sc = new Scanner(System.in);
             int[] A;
             int i, n, k, t;
             A = new int[10];
             A[0] = 5;
             A[1] = 6;
             A[2] = 8;
              A[3] = 5;
             A[4] = 9;
             A[5] = 4;
             A[6] = 10;
             A[7] = 1;
             A[8] = 2;
             A[9] = 3;
             
             k = sc.nextInt();
             for(n = 0; n<k; n++){
                 t = A[9];
                 for(i = 8; i >=0;i--){
                     A[i+1]= A[i];
                 }
                 A[0] = t;
             }
             System.out.println( A[0] );
             System.out.println( A[1] );
             System.out.println( A[2] );
             System.out.println( A[3] );
             System.out.println( A[4] );
             System.out.println( A[5] );
             System.out.println( A[6] );
             System.out.println( A[7] );
             System.out.println( A[8] );
             System.out.println( A[9] );
             
        }
    }