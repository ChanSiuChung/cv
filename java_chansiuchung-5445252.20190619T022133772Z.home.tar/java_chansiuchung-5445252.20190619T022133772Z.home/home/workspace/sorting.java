import java.util.Scanner;
    class sort {
        public static void main(String args[]){
            int[] array = {1, 6 ,5,4, 1};
            int min, minpos;
            min = array[0];
            minpos = 0;
            for(int j = 0;j < 5; j++){
                min = array[j];
                minpos = j;
                for(int i = j;i < 4;i++){
                    if(array[j] > array[i + 1]){
                        min = array[i + 1];
                        minpos = i + 1;
                    }
                    int swap = array[j];
                    array[j] = array[minpos];
                    array[minpos] = swap;
                    
                }
            }
            for(int k = 0;k < 5;k++){
                System.out.println(array[k]);
            }
            
        
        }
    }