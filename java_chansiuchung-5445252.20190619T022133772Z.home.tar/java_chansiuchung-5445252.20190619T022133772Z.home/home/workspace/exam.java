import java.util.Scanner;
    class prepexam{
        public static void main(String args[]){
            Scanner hahaha = new Scanner(System.in);
            int h, w;
            h = hahaha.nextInt();
            w = hahaha.nextInt();
            //System.out.println(h);
            //System.out.println(w);
            hahaha.nextLine();
            String maze = hahaha.nextLine();
            System.out.println(maze);
        }
    }