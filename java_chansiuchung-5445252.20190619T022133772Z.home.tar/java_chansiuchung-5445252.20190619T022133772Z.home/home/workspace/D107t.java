import java.util.Scanner;
    class primenumber{
        public static void main (String args[]) {
            Scanner sc = new Scanner(System.in);
            int a, c;
            a = sc.nextInt();
            boolean flag;
            flag = false;
            c = 0;
            while (c < a && flag == false ){
                System.out.println("HIIII");
                c = c+1;
            }

            }
        }
    