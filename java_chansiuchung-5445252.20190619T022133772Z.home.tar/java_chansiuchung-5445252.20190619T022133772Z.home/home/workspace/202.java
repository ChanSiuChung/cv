import java.util.Scanner;
    class date202{
        public static void main (String args[]) {
            Scanner di = new Scanner(System.in);
            int i, j, k;
            k = di.nextInt();
            for(i = 0; i < k; i++){
                for(j = 1; j <= k; j++){
                    if(j != k){
                        System.out.print((j + i) * (j + i));
                        System.out.print(" ");
                    }else{
                        System.out.println((j + i) * (j + i));
                    }
                }
            }
        }
    }