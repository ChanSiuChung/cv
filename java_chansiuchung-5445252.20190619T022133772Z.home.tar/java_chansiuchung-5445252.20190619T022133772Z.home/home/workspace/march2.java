import java.util.Scanner;

    class march2{
        public static int I;
        
        public static void main(String [] args){
            I = 3;
            methodA();
        }
        
        public static void methodA(){
            I = 4;
            methodB();
            System.out.println(I);
        }
        
        public static void methodB(){
            int I;
            I = 5;
        }
    }