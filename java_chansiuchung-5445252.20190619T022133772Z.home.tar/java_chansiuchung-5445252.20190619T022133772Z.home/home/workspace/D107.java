import java.util.Scanner;
    class d107{
        public static void main (String args[]) {
            Scanner sc = new Scanner(System.in);
            int a = sc.nextInt();
            int b, c, d, n;
            boolean flag, flag2;
        //Triangular
            flag2 = false;
            d = 0;
            for(c = 1;c <= a; c++){
                d = c* (c+1)/2;
                if (a - d == 0){
                     flag2 = true;
                }

            }
        //Square
            flag = false;
            for(b = 1; b * b <= a; b++){
                if (b * b == a){
                    flag = true;
                }
            }
            if (flag == true &&  flag2 == true){
            System.out.println("Both");
            }else if( flag == true && flag2 == false){
                System.out.println("Square");
            }else if( flag == false && flag2 == true){
                System.out.println("Triangular");
            }else{
                System.out.println("Neither");
            }
        }
    }
    