import java.util.Scanner;
class Main{
    public static void main(String args[]){
        String myname;
        Scanner di = new Scanner(System.in);
        myname = di.nextLine();
        System.out.println("Hello ");
        System.out.println(myname);
    }
}