import java.util.Scanner;
    class search {
    
        public static void main(String args[]) {
            Scanner di = new Scanner(System.in);
            int[] data = new int[]{20, 30, 40, 50, 60, 89};
            int target;
            System.out.print("what is the target? :");
            target = di.nextInt();
            boolean cont = true;
            for(int i = 0;i < 6 && cont ;i++){
                if(target == data[i]){
                    System.out.println("target is :" + target);
                    System.out.println("position:" + i);
                    cont = false;
                }
            }
            if(cont){
                System.out.println("Target Not Found");
            }
        }
    }