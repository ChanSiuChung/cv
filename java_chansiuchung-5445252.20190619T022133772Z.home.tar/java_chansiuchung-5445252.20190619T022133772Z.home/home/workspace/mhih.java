import java.util.Scanner;

    class q556 {
        public static void main (String args[]) {
            Scanner datain = new Scanner(System.in);
            while (3 == 3){
                System.out.println("Mr.HUI is Handsome");
            }
        }
    }