import java.util.Scanner;

    class valid {
        public static void main (String args[]) {
            Scanner datain = new Scanner(System.in);
            double A;
            System.out.println("What is the score?");
            A = datain.nextDouble();
            if (A <= 100 & A >= 0) {
                System.out.println("valid");
            }else { System.out.println("invalid"); }
        }
    }