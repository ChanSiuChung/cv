import java.util.Scanner;
    class d101{
        public static void main (String args[]) {
             Scanner sc = new Scanner(System.in);
             int a ;
             a = sc.nextInt();
             if(a >= 20000000 && a < 40000000){
                 System.out.println("Fixed");
             }else if(a >= 50000000 && a < 70000000){
                 System.out.println("Mobile");
             }else if( a >= 90000000 && a <100000000 ){
                 System.out.println("Mobile");
             }
        }
    }