class phappy{ 
    public static void main(String[] args) {
        printH();
        printA();
        printP();
        printP();
        printP();
        printP();
        printY();
    }
    
    public static void printH(){
        System.out.println(" _   _  ");
        System.out.println("( )_( ) ");
        System.out.println(" ) _ (  ");
        System.out.println("(_) (_) ");
    }
    
    public static void printA(){
        System.out.println("   __   ");
        System.out.println("  /__\\  ");
        System.out.println(" /(__)\\ ");
        System.out.println("(__)(__)");
    }
    
    public static void printP(){
        System.out.println(" ____   ");
        System.out.println("(  _ \\  ");
        System.out.println(" )___/  ");
        System.out.println("(__)    ");
    }
    
    public static void printY(){
        System.out.println(" _  _   ");
        System.out.println("( \\/ )  ");
        System.out.println(" \\  /   ");
        System.out.println(" (__)   ");
    }
}