import java.util.Scanner;
    
    class a11172017 {
        public static void main (String args[]) {
        int a;
        Scanner datain = new Scanner(System.in);
        a = datain.nextInt();
        a = a + 1;
        System.out.println(a);
        }
    }
        