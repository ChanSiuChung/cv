import java.util.Scanner;
    class ttt{
        public static void main (String args[]) {
            Scanner di = new Scanner(System.in);
            int a, b, c, choice, e;
            char[][] array = new char[3][3];
            e = 1;
            while( e == 1){
            //Starting Page
            System.out.println("========================================================");
            System.out.println("HELLO, Welcome to TIC-TAC-TOE");
            System.out.println("Press");
            System.out.println("1. Start the game");
            System.out.println("2. Rules");
            System.out.println("3. Exit");
            System.out.println("========================================================");
            choice = di.nextInt();
            while (choice > 3 || choice < 1){
                System.out.println("========================================================");
                System.out.println("Please select your option ");
                System.out.println("Press");
                System.out.println("1. Start the game");
                System.out.println("2. Rules");
                System.out.println("3. Exit");
                System.out.println("========================================================");
                choice = di.nextInt();
                }
            if (choice == 3){
                System.out.println("BYEBYE!");
                System.exit(0);
            }else if(choice == 2){
                System.out.println("Get 3 in a row, each person must switch taking turns, first X, then O.");
                System.out.println("3 letters must all connect in a straight line in one direction, up or down, left or right, or diagonally.");
            }else if(choice == 1){
                //put the body back is ok
                            //input 0 into all array
            for(a = 0;a < 3;a++){
                for(b =0;b < 3;b++){
                    array[a][b] = '.';
                }
            }
            //the main body
            //X turn
            int x, y;
            char z;
            boolean flag = true , flag2 = true;
            c = 1;
            do{
                System.out.println("Player X's turn, please enter x-axis of X you want to put:");
                x = di.nextInt();
                x = x - 1; 
                System.out.println("Player X's turn, please enter y-axis of X you want to put:");
                y = di.nextInt();
                y = y - 1;
                //do sorting and print and check
                array[y][x] = 'X';
                for(a = 0;a < 3;a++){
                    for(b =0;b < 3;b++){
                        if(b != 2){
                            System.out.print(array[a][b]);
                        }else{
                            System.out.println(array[a][b]);
                        }
                    }
                }
                //check horiz
            for(x = 0;x < 3;x++){
                for(y = 0;y < 3;y++){
                    if(array[y][x] == 'X'){
                        flag = true;
                    }else{
                        flag = false;
                    }
                    if (flag == false){
                        break;
                    }
                }
            }
                if (flag == true){
                    System.out.println("X wins");
                    System.out.println("Press");
                    System.out.println("1. Next match");
                    System.out.println("2. End game");
                    e = di.nextInt();
                    if(e == 2){
                    System.exit(0);
                    }
                }   
            
                //vertical
                for(y = 0;y < 3;y++){
                    for(x = 0;x < 3;x++){
                        if(array[y][x] == 'X'){
                            flag = true;
                        }else{
                            flag = false;
                        }
                        if (flag == false){
                            break;
                        }
                    }
                    if (flag == true){
                        System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        e = di.nextInt();
                        if(e == 2){
                            System.exit(0);
                        }
                }
                    //diagonals l to r
                    for(y = 0; y < 3;y++){
                        if (array[y][y] == 'X'){
                            flag = true;
                        }else{
                            flag = false;
                        }
                        if(flag == false){
                            break;
                        }
                    }
                    if (flag == true){
                        System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        e = di.nextInt();
                        if(e == 2){
                            System.exit(0);
                        }
                    }
                // r to l
                //ERROR OCCUR
                y = 0;
                for(x = 2;x >= 0;x--){
                        if(array[y][x] == 'X'){
                            flag = true;
                        }else{
                            flag = false;
                        }
                        if(flag == false){
                            break;
                        }
                        y++;
                    
                }
                if(flag == true){
                    System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        e = di.nextInt();
                        if(e == 2){
                            System.exit(0);
                        }
                }
                //////////////////////////////////////
                System.out.println("Player Y's turn, please enter x-axis of O you want to put:");
                x = di.nextInt();
                x = x - 1;
                System.out.println("Player Y's turn, please enter y-axis of O you want to put:");
                y = di.nextInt();
                y = y - 1;
                //do sorting and print and check
                array[y][x] = 'O';
                for(a = 0;a < 3;a++){
                    for(b =0;b < 3;b++){
                        if(b != 2){
                            System.out.print(array[a][b]);
                        }else{
                            System.out.println(array[a][b]);
                        }
                    }
                }
                //check horiz
            for(x = 0;x < 3;x++){
                for(y = 0;y < 3;y++){
                    if(array[y][x] == 'O'){
                        flag2 = true;
                    }else{
                        flag2 = false;
                    }
                    if (flag2 == false){
                        break;
                    }
                }
            }
                if (flag2 == true){
                        System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        e = di.nextInt();
                        if(e == 2){
                            System.exit(0);
                        }
                    }
            
                //vertical
                for(y = 0;y < 3;y++){
                    for(x = 0;x < 3;x++){
                        if(array[y][x] == 'O'){
                            flag2 = true;
                        }else{
                            flag2 = false;
                        }
                        if (flag2 == false){
                            break;
                        }
                    }
                    if (flag2 == true){
                            System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        e = di.nextInt();
                        if(e == 2){
                            System.exit(0);
                        }
                    }
                
                    //diagonals l to r
                    for(y = 0; y < 3;y++){
                        if (array[y][y] == 'O'){
                            flag2 = true;
                        }else{
                            flag2 = false;
                        }
                        if(flag2 == false){
                            break;
                        }
                    }
                    if (flag2 == true){
                        System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        e = di.nextInt();
                        if(e == 2){
                            System.exit(0);
                        }
                    }
                // r to l
                //ERROR OCCUR
                y = 0;
                for(x = 2;x >= 0;x--){
                        if(array[y][x] == 'O'){
                            flag2 = true;
                        }else{
                            flag2 = false;
                        }
                        if(flag2 == false){
                            break;
                        }
                        y++;
                    
                }
                if(flag2 == true){
                    System.out.println("X wins");
                        System.out.println("Press");
                        System.out.println("1. Next match");
                        System.out.println("2. End game");
                        e = di.nextInt();
                        if(e == 2){
                            System.exit(0);
                        }
                }
                ///////////////////////////////////////
                c++;
                }while (c < 6);
            
