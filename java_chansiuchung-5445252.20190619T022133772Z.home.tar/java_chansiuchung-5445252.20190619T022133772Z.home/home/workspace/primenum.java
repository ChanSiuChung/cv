import java.util.Scanner;
    class primenumber{
        public static void main (String args[]) {
            Scanner sc = new Scanner(System.in);
            int a, c;
            a = sc.nextInt();
            boolean flag;
            flag = false;
            c = 2;
            if( a == 1){
                System.out.println("no");
            }else{
                while (c < a && flag == false ){
                    if (a % c  == 0){
                        flag = true;
                    }c = c+1;
                }
                if (flag == false){
                    System.out.println("yes");
                }else{
                    System.out.println("no");
                }
            }
        }
    }   