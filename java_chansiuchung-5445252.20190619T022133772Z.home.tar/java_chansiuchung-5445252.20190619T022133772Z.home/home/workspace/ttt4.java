import java.util.Scanner;
    class tttcheck{
        public static void main (String args[]) {
for(g = 0;g == 0;){
                        h = 0;
                        checkloop:
                        do{
                            System.out.println("Player O's turn, please enter x-axis of O you want to put:");
                            x = di.nextInt();
                            x = x - 1; 
                            System.out.println("Player O's turn, please enter y-axis of O you want to put:");
                            y = di.nextInt();
                            y = y - 1;
                            if (y > 2 || y < 0|| x > 2|| x <0){
                                System.out.println("ERROR, please try again");
                                break checkloop;
                            }else if(array[y][x] != '.'){
                                System.out.println("ERROR, please try again");
                                break checkloop;
                            }else{
                                array[y][x] = 'O';
                            for(a = 0;a < 3;a++){
                                for(b =0;b < 3;b++){
                                    if(b != 2){
                                        System.out.print(array[a][b]);
                                    }else{
                                        System.out.println(array[a][b]);
                                    }
                                }
                            }
                            h = h + 1;
                            g = g + 1;
                            }
                        }while( h == 0);
                    }
        }
    }