import java.util.Scanner;
    class game {
        public static void main(String args[]){
        int a = hi();
        System.out.println(a);
        }
        
        public static int hi(){
            return 9;
        }
        
    }
